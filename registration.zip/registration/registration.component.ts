import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-registration',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink], // Import necessary modules
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css'] // Use styleUrls (plural)
})
export class RegistrationComponent {

  registrationForm: FormGroup; // Declare the registrationForm property

  constructor() { // Initialize the form group with the required controls and validators
    this.registrationForm =new FormGroup({
      username: new FormControl('', [Validators.required, Validators.minLength(3)]),
      email:  new FormControl('', [Validators.required, Validators.email]),
      password:  new FormControl('', [Validators.required, Validators.minLength(8), Validators.pattern('^[^\\s]+$')]) // No spaces allowed
    });
  }
  

  // Function to handle form submission
  onLoginSubmit(): void {
    if (this.registrationForm.valid) {
      // Handle the form submission, e.g., send the data to the server
      console.log(this.registrationForm.value);
    } else {
      console.log('Form is invalid');
    }
  }
}
