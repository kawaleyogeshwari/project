import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-customer-service-booking',
  standalone: true,
  imports: [CommonModule,FormsModule],
  templateUrl: './customer-service-booking.component.html',
  styleUrl: './customer-service-booking.component.css'
})
export class CustomerServiceBookingComponent {
  booking = {
    customerName: '',
    area: '',
    pincode: '',
    phoneNumber: '',
    price: 1200,
    serviceCount: 1,
    dateTime: '',
  };
  successMessage: boolean = false;

  calculateTotalPrice(): number {
    return this.booking.price * this.booking.serviceCount;
  }

  submitBooking(): void {
    this.successMessage = true;
    console.log('Booking Data:', this.booking);
  }
}
